<?php
// This translation has not been verified by a native speaker.
// Irish
// Last update: 2020.04.16
$pt['en'] = 'ga';
$pt['Click to continue'] = 'Cliceáil chun leanúint ar aghaidh';
$pt['Just a moment...'] = 'Fan.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Cas JavaScript air agus athlódáil an leathanach.';
$pt['Checking your browser before accessing the website.'] = 'Seiceáil do bhrabhsálaí sula ndéanann tú rochtain ar an suíomh.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Tá an próiseas seo uathoibríoch. Déanfaidh do bhrabhsálaí atreorú chuig an ábhar iarrtha atá agat gan mhoill.';
$pt['Please wait a few seconds:'] = 'Fan cúpla soicind le do thoil:';
