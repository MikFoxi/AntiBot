<?php
// This translation has not been verified by a native speaker.
// Español
// Last update: 2021.08.17
$pt['en'] = 'es';
$pt['Click to continue'] = 'Haz click para continuar';
$pt['Just a moment...'] = 'Espere.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Active JavaScript y vuelva a cargar la página.';
$pt['Checking your browser before accessing the website.'] = 'Verificando su navegador antes de acceder al sitio.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Este proceso es automático. Su navegador redirigirá a su contenido solicitado en breve.';
$pt['Please wait a few seconds.'] = 'Por favor espere unos segundos.';
$pt['Loading page, please wait...'] = 'Cargando página, por favor espere...';
$pt['BLACK'] = 'NEGRO';
$pt['GRAY'] = 'GRIS';
$pt['PURPLE'] = 'PÚRPURA';
$pt['RED'] = 'ROJO';
$pt['YELLOW'] = 'AMARILLO';
$pt['GREEN'] = 'VERDE';
$pt['BLUE'] = 'AZUL';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Si eres humano, haz clic en el botón con el color más parecido a este:';
