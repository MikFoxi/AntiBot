<?php
// This translation has not been verified by a native speaker.
// Español
// Last update: 2020.04.30
$pt['en'] = 'es';
$pt['Click to continue'] = 'Haz click para continuar';
$pt['Just a moment...'] = 'Espere.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Active JavaScript y vuelva a cargar la página.';
$pt['Checking your browser before accessing the website.'] = 'Verificando su navegador antes de acceder al sitio.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Este proceso es automático. Su navegador redirigirá a su contenido solicitado en breve.';
$pt['Please wait a few seconds.'] = 'Por favor espere unos segundos.';
