<?php
// This translation has not been verified by a native speaker.
// Indonesian
// Last update: 2021.08.17
$pt['en'] = 'id';
$pt['Click to continue'] = 'Klik untuk melanjutkan';
$pt['Just a moment...'] = 'Tunggu.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Silakan aktifkan JavaScript dan muat ulang halaman.';
$pt['Checking your browser before accessing the website.'] = 'Memeriksa browser Anda sebelum mengakses situs.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Proses ini otomatis. Peramban Anda akan segera mengarahkan ulang ke konten yang Anda minta.';
$pt['Please wait a few seconds.'] = 'Harap tunggu beberapa detik.';
$pt['Loading page, please wait...'] = 'Memuat halaman, harap tunggu...';
$pt['BLACK'] = 'BLACK';
$pt['GRAY'] = 'ABU-ABU';
$pt['PURPLE'] = 'UNGU';
$pt['RED'] = 'MERAH';
$pt['YELLOW'] = 'KUNING';
$pt['GREEN'] = 'HIJAU';
$pt['BLUE'] = 'BIRU';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Jika Anda manusia, klik tombol dengan warna yang paling mirip dengan yang ini:';
