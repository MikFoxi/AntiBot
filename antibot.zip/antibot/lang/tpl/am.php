<?php
// This translation has not been verified by a native speaker.
// Amharic
// Last update: 2020.04.16
$pt['en'] = 'am';
$pt['Click to continue'] = 'ለመቀጠል ጠቅ ያድርጉ';
$pt['Just a moment...'] = 'ጠብቅ.';
$pt['Please turn JavaScript on and reload the page.'] = 'እባክዎ ጃቫስክሪፕትን ያብሩ እና ገጹን እንደገና ይጫኑት።';
$pt['Checking your browser before accessing the website.'] = 'ጣቢያውን ከመድረስዎ በፊት አሳሽዎን መፈተሽ።';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'ይህ ሂደት ራስ-ሰር ነው። አሳሽዎ በቅርቡ ወደጠየቁት ይዘትዎ አቅጣጫውን ያዞረዋል።';
$pt['Please wait a few seconds:'] = 'እባክዎ ጥቂት ሰከንዶች ይጠብቁ';
