<?php
// This translation has not been verified by a native speaker.
// Finnish (suomi)
// Last update: 2020.04.30
$pt['en'] = 'fi';
$pt['Click to continue'] = 'Klikkaa jatkaaksesi';
$pt['Just a moment...'] = 'Odota.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Ota JavaScript käyttöön ja lataa sivu uudelleen.';
$pt['Checking your browser before accessing the website.'] = 'Selaimen tarkistaminen ennen pääsyä sivustoon.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Tämä prosessi on automaattinen. Selaimesi ohjaa pian pyydettyyn sisältöön.';
$pt['Please wait a few seconds.'] = 'Odota muutama sekunti.';
