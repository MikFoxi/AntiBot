<?php
// This translation has not been verified by a native speaker.
// Georgian
// Last update: 2020.04.30
$pt['en'] = 'ka';
$pt['Click to continue'] = 'დააჭირეთ გასაგრძელებლად';
$pt['Just a moment...'] = 'დაელოდე.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'გთხოვთ ჩართოთ JavaScript და განაახლეთ გვერდი.';
$pt['Checking your browser before accessing the website.'] = 'საიტის წვდომამდე ბრაუზერის შემოწმება.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'ეს პროცესი ავტომატურია. თქვენი ბრაუზერი გადამისამართდება თქვენს მოთხოვნილ შინაარსზე მალე.';
$pt['Please wait a few seconds.'] = 'გთხოვთ, დაელოდოთ რამდენიმე წამს';
