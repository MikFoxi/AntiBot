<?php
// This translation has not been verified by a native speaker.
// Georgian
// Last update: 2021.03.03
$pt['en'] = 'ka';
$pt['Click to continue'] = 'დააჭირეთ გასაგრძელებლად';
$pt['Just a moment...'] = 'დაელოდე.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'გთხოვთ ჩართოთ JavaScript და განაახლეთ გვერდი.';
$pt['Checking your browser before accessing the website.'] = 'საიტის წვდომამდე ბრაუზერის შემოწმება.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'ეს პროცესი ავტომატურია. თქვენი ბრაუზერი გადამისამართდება თქვენს მოთხოვნილ შინაარსზე მალე.';
$pt['Please wait a few seconds.'] = 'გთხოვთ, დაელოდოთ რამდენიმე წამს';
$pt['Loading page, please wait...'] = 'გვერდის ჩატვირთვა, გთხოვთ, დაელოდოთ ...';
$pt['BLACK'] = 'შავი';
$pt['GRAY'] = 'ნაცრისფერი';
$pt['PURPLE'] = 'იასამნისფერი';
$pt['RED'] = 'წითელი';
$pt['YELLOW'] = 'ყვითელი';
$pt['GREEN'] = 'მწვანე';
$pt['BLUE'] = 'ლურჯი';
$pt['To verify that you are not a robot, click on the button with color:'] = 'თუ თქვენ რობოტი არ ხართ, დააჭირეთ ღილაკს ფერით:';
