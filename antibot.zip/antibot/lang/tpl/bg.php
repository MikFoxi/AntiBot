<?php
// This translation has not been verified by a native speaker.
// Bulgarian
// Last update: 2020.04.30
$pt['en'] = 'bg';
$pt['Click to continue'] = 'Кликнете, за да продължите';
$pt['Just a moment...'] = 'Изчакайте.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Моля, включете JavaScript и презаредете страницата.';
$pt['Checking your browser before accessing the website.'] = 'Проверка на вашия браузър, преди да получите достъп до сайта.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Този процес е автоматичен. Вашият браузър скоро ще пренасочи към заявеното ви съдържание.';
$pt['Please wait a few seconds.'] = 'Моля, изчакайте няколко секунди.';
