<?php
// Last update: 2020.05.18
$pt['en'] = 'ru';
$pt['Click to continue'] = 'Нажмите для продолжения';
$pt['Just a moment...'] = 'Идет проверка...';
$pt['Please turn JavaScript on and reload the page.'] = 'Пожалуйста, включите JavaScript и перезагрузите страницу.';
$pt['Checking your browser before accessing the website.'] = 'Проверка вашего браузера перед доступом к сайту.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Этот процесс автоматический. Ваш браузер будет перенаправлен на запрошенный контент в ближайшее время.';
$pt['Please wait a few seconds.'] = 'Пожалуйста, подождите несколько секунд.';
$pt['Loading page, please wait...'] = 'Идет загрузка страницы, подождите...';
