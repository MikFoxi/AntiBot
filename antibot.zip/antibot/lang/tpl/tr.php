<?php
// This translation has not been verified by a native speaker.
// Türkçe
// Last update: 2020.04.30
$pt['en'] = 'tr';
$pt['Click to continue'] = 'Devam etmek için tıklayın';
$pt['Just a moment...'] = 'Bekle.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Lütfen JavaScript\'i açın ve sayfayı yeniden yükleyin.';
$pt['Checking your browser before accessing the website.'] = 'Siteye erişmeden önce tarayıcınızı kontrol edin.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Bu işlem otomatiktir. Tarayıcınız kısa süre içinde istediğiniz içeriğe yönlendirecektir.';
$pt['Please wait a few seconds.'] = 'Lütfen birkaç saniye bekleyin.';
