<?php
// This translation has not been verified by a native speaker.
// Türkçe
// Last update: 2021.08.17
$pt['en'] = 'tr';
$pt['Click to continue'] = 'Devam etmek için tıklayın';
$pt['Just a moment...'] = 'Bekle.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Lütfen JavaScript\'i açın ve sayfayı yeniden yükleyin.';
$pt['Checking your browser before accessing the website.'] = 'Siteye erişmeden önce tarayıcınızı kontrol edin.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Bu işlem otomatiktir. Tarayıcınız kısa süre içinde istediğiniz içeriğe yönlendirecektir.';
$pt['Please wait a few seconds.'] = 'Lütfen birkaç saniye bekleyin.';
$pt['Loading page, please wait...'] = 'Sayfa yükleniyor, lütfen bekleyin...';
$pt['BLACK'] = 'SİYAH';
$pt['GRAY'] = 'GRİ';
$pt['PURPLE'] = 'MOR';
$pt['RED'] = 'KIRMIZI';
$pt['YELLOW'] = 'SARI';
$pt['GREEN'] = 'YEŞİL';
$pt['BLUE'] = 'MAVİ';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Eğer insansanız, buna en çok benzeyen renge sahip düğmeye tıklayın:';
