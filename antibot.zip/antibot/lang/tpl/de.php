<?php
// This translation has not been verified by a native speaker.
// German
// Last update: 2020.04.30
$pt['en'] = 'de';
$pt['Click to continue'] = 'Klicke um Fortzufahren';
$pt['Just a moment...'] = 'Warten.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Bitte schalten Sie JavaScript ein und laden Sie die Seite neu.';
$pt['Checking your browser before accessing the website.'] = 'Überprüfen Sie Ihren Browser, bevor Sie auf die Website zugreifen.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Dieser Vorgang erfolgt automatisch. Ihr Browser wird in Kürze zu Ihrem gewünschten Inhalt umleiten.';
$pt['Please wait a few seconds.'] = 'Bitte warten Sie einige Sekunden.';
