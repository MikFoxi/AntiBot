<?php
// This translation has not been verified by a native speaker.
// Portuguese
// Last update: 2020.04.16
$pt['en'] = 'pt';
$pt['Click to continue'] = 'Clique para continuar';
$pt['Just a moment...'] = 'Esperar.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Ative o JavaScript e recarregue a página.';
$pt['Checking your browser before accessing the website.'] = 'Verificando seu navegador antes de acessar o site.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Este processo é automático. Seu navegador será redirecionado para o conteúdo solicitado em breve.';
$pt['Please wait a few seconds:'] = 'Aguarde alguns segundos:';
