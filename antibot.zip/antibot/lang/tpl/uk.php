<?php
// Український
// Last update: 2021.03.04
$pt['en'] = 'uk';
$pt['Click to continue'] = 'Натисніть для продовження';
$pt['Just a moment...'] = 'Триває перевірка...';
$pt['Please turn JavaScript on and reload the page.'] = 'Будь ласка, включіть JavaScript і перезавантажте сторінку.';
$pt['Checking your browser before accessing the website.'] = 'Перевірка вашого браузера перед доступом до сайту.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Цей процес автоматичний. Ваш браузер буде перенаправлений на запитаний контент найближчим часом.';
$pt['Please wait a few seconds.'] = 'Будь ласка, зачекайте кілька секунд.';
$pt['Loading page, please wait...'] = 'Завантаження сторінки, будь ласка, зачекайте ...';
$pt['BLACK'] = 'ЧОРНИЙ';
$pt['GRAY'] = 'СІРИЙ';
$pt['PURPLE'] = 'ФІОЛЕТОВИЙ';
$pt['RED'] = 'ЧЕРВОНИЙ';
$pt['YELLOW'] = 'ЖОВТИЙ';
$pt['GREEN'] = 'ЗЕЛЕНИЙ';
$pt['BLUE'] = 'СИНІЙ';
$pt['To verify that you are not a robot, click on the button with color:'] = 'Якщо ви не робот, то натисніть на кнопку з кольором:';
