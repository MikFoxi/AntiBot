<?php
// This translation has not been verified by a native speaker.
// Беларуская мова
// Last update: 2020.04.30
$pt['en'] = 'be';
$pt['Click to continue'] = 'Націсніце, каб працягнуць';
$pt['Just a moment...'] = 'Пачакайце...'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Уключыце JavaScript і перазагрузіце старонку.';
$pt['Checking your browser before accessing the website.'] = 'Праверка браўзэра, перш чым атрымаць доступ да сайта.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Гэты працэс аўтаматычны. Неўзабаве ваш браўзэр перанакіруе на патрэбны вам кантэнт.';
$pt['Please wait a few seconds.'] = 'Пачакайце некалькі секунд.';
