<?php
// This translation has not been verified by a native speaker.
// Greek
// Last update: 2021.03.03
$pt['en'] = 'el';
$pt['Click to continue'] = 'Κάντε κλικ για να συνεχίσετε';
$pt['Just a moment...'] = 'Περίμενε.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Ενεργοποιήστε τη JavaScript και επαναλάβετε τη φόρτωση της σελίδας.';
$pt['Checking your browser before accessing the website.'] = 'Ελέγξτε το πρόγραμμα περιήγησής σας πριν από την πρόσβαση στον ιστότοπο.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Αυτή η διαδικασία είναι αυτόματη. Το πρόγραμμα περιήγησής σας θα μεταφερθεί σύντομα στο ζητούμενο περιεχόμενο.';
$pt['Please wait a few seconds.'] = 'Περιμένετε μερικά δευτερόλεπτα';
$pt['Loading page, please wait...'] = 'Φόρτωση σελίδας, περιμένετε...';
$pt['BLACK'] = 'ΜΑΥΡΟΣ';
$pt['GRAY'] = 'ΓΚΡΙ';
$pt['PURPLE'] = 'ΜΩΒ';
$pt['RED'] = 'ΚΌΚΚΙΝΟ';
$pt['YELLOW'] = 'ΚΙΤΡΙΝΟΣ';
$pt['GREEN'] = 'ΠΡΑΣΙΝΟΣ';
$pt['BLUE'] = 'ΜΠΛΕ';
$pt['To verify that you are not a robot, click on the button with color:'] = 'Εάν δεν είστε ρομπότ, κάντε κλικ στο κουμπί με το χρώμα:';
