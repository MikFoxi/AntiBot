<?php
// This translation has not been verified by a native speaker.
// Greek
// Last update: 2020.05.18
$pt['en'] = 'el';
$pt['Click to continue'] = 'Κάντε κλικ για να συνεχίσετε';
$pt['Just a moment...'] = 'Περίμενε.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Ενεργοποιήστε τη JavaScript και επαναλάβετε τη φόρτωση της σελίδας.';
$pt['Checking your browser before accessing the website.'] = 'Ελέγξτε το πρόγραμμα περιήγησής σας πριν από την πρόσβαση στον ιστότοπο.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Αυτή η διαδικασία είναι αυτόματη. Το πρόγραμμα περιήγησής σας θα μεταφερθεί σύντομα στο ζητούμενο περιεχόμενο.';
$pt['Please wait a few seconds.'] = 'Περιμένετε μερικά δευτερόλεπτα';
$pt['Loading page, please wait...'] = 'Φόρτωση σελίδας, περιμένετε...';
