<?php
// This translation has not been verified by a native speaker.
// Kazakh
// Last update: 2021.08.17
$pt['en'] = 'kk';
$pt['Click to continue'] = 'Жалғастыру үшін басыңыз';
$pt['Just a moment...'] = 'Күте тұрыңыз.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'JavaScript қосыңыз және бетті қайта жүктеңіз.';
$pt['Checking your browser before accessing the website.'] = 'Сайтқа кірмес бұрын шолғышты тексеру.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Бұл процесс автоматты. Жақында сіздің браузеріңіз сұралған мазмұнға қайта бағытталады.';
$pt['Please wait a few seconds.'] = 'Бірнеше секунд күтіңіз.';
$pt['Loading page, please wait...'] = 'Парақ жүктелуде, күте тұрыңыз...';
$pt['BLACK'] = 'ҚАРА';
$pt['GRAY'] = 'САР';
$pt['PURPLE'] = 'КҮЛГІН';
$pt['RED'] = 'ҚЫЗЫЛ';
$pt['YELLOW'] = 'САРЫ';
$pt['GREEN'] = 'ЖАСЫЛ';
$pt['BLUE'] = 'КӨК';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Егер сіз адам болсаңыз, осы түске ұқсас батырманы басыңыз:';
