<?php
// This translation has not been verified by a native speaker.
// Norwegian
// Last update: 2020.04.16
$pt['en'] = 'no';
$pt['Click to continue'] = 'Klikk for å fortsette';
$pt['Just a moment...'] = 'Vente.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Vennligst slå JavaScript på og last inn siden på nytt.';
$pt['Checking your browser before accessing the website.'] = 'Kontroller nettleseren din før du går inn på nettstedet.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Denne prosessen er automatisk. Nettleseren din vil viderekoble til det forespurte innholdet om kort tid.';
$pt['Please wait a few seconds:'] = 'Vent noen sekunder:';
