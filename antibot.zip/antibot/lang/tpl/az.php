<?php
// This translation has not been verified by a native speaker.
// Azerbaijani
// Last update: 2021.08.17
$pt['en'] = 'az';
$pt['Click to continue'] = 'Davam etmək üçün vurun';
$pt['Just a moment...'] = 'Bir dəqiqə...';
$pt['Please turn JavaScript on and reload the page.'] = 'Zəhmət olmasa JavaScripti yandırın və səhifəni yenidən yükləyin.';
$pt['Checking your browser before accessing the website.'] = 'Sayta girmədən əvvəl brauzerinizi yoxlayır.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Bu proses avtomatikdir. Brauzeriniz qısa müddətdə tələb olunan məzmuna yönləndiriləcəkdir.';
$pt['Please wait a few seconds.'] = 'Zəhmət olmasa bir neçə saniyə gözləyin.';
$pt['Loading page, please wait...'] = 'Səhifə yüklənir, zəhmət olmasa gözləyin...';
$pt['BLACK'] = 'QARA';
$pt['GRAY'] = 'BOZ';
$pt['PURPLE'] = 'BƏNÖVŞƏYI';
$pt['RED'] = 'QIRMIZI';
$pt['YELLOW'] = 'SARI';
$pt['GREEN'] = 'YAŞIL';
$pt['BLUE'] = 'MAVI';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'İnsansınızsa, bu rəngə ən çox bənzəyən düyməni basın:';
