<?php
// This translation has not been verified by a native speaker.
// Armenian
// Last update: 2020.04.30
$pt['en'] = 'hy';
$pt['Click to continue'] = 'Կտտացրեք ՝ շարունակելու համար';
$pt['Just a moment...'] = 'Սպասեք'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Խնդրում ենք միացնել JavaScript- ը և վերաբեռնել էջը:';
$pt['Checking your browser before accessing the website.'] = 'Ստուգելով ձեր զննարկիչը կայք մուտք գործելուց առաջ:';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Այս գործընթացը ավտոմատ է: Ձեր զննարկիչը շուտով կուղեկցի ձեր հայցվող բովանդակությանը:';
$pt['Please wait a few seconds.'] = 'Խնդրում ենք սպասել մի քանի վայրկյան.';
