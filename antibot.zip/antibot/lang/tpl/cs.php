<?php
// This translation has not been verified by a native speaker.
// Czech
// Last update: 2020.04.30
$pt['en'] = 'cs';
$pt['Click to continue'] = 'Klikni pro pokračování';
$pt['Just a moment...'] = 'Počkejte.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Zapněte prosím JavaScript a znovu načtěte stránku.';
$pt['Checking your browser before accessing the website.'] = 'Před přístupem na web zkontrolujte svůj prohlížeč.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Tento proces je automatický. Váš prohlížeč brzy přesměruje na požadovaný obsah.';
$pt['Please wait a few seconds.'] = 'Počkejte prosím několik sekund.';
