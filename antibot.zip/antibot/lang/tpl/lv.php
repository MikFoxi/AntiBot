<?php
// This translation has not been verified by a native speaker.
// Latvian
// Last update: 2021.03.03
$pt['en'] = 'lv';
$pt['Click to continue'] = 'Noklikšķiniet, lai turpinātu';
$pt['Just a moment...'] = 'Pagaidiet.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Lūdzu, ieslēdziet JavaScript un atkārtoti ielādējiet lapu.';
$pt['Checking your browser before accessing the website.'] = 'Pārbaudiet savu pārlūkprogrammu pirms piekļuves vietnei.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Šis process notiek automātiski. Drīzumā jūsu pārlūkprogramma novirzīs uz jūsu pieprasīto saturu.';
$pt['Please wait a few seconds.'] = 'Lūdzu, uzgaidiet dažas sekundes.';
$pt['Loading page, please wait...'] = 'Notiek lapas ielāde, lūdzu, uzgaidiet...';
$pt['BLACK'] = 'MELNA';
$pt['GRAY'] = 'PELĒKA';
$pt['PURPLE'] = 'VIOLETS';
$pt['RED'] = 'SARKANS';
$pt['YELLOW'] = 'DZELTENS';
$pt['GREEN'] = 'ZAĻA';
$pt['BLUE'] = 'ZILA';
$pt['To verify that you are not a robot, click on the button with color:'] = 'Ja neesat robots, noklikšķiniet uz pogas ar krāsu:';
