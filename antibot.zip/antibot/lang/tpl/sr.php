<?php
// This translation has not been verified by a native speaker.
// Srpski
// Last update: 2020.04.16
$pt['en'] = 'sr';
$pt['Click to continue'] = 'Kliknite da nastavite';
$pt['Just a moment...'] = 'Provera je u toku...';
$pt['Please turn JavaScript on and reload the page.'] = 'Molim da omogućite JavaScript u pregledaču i ponovo učitate stranicu.';
$pt['Checking your browser before accessing the website.'] = 'Provera vašeg pregledača pre pristupa stranici.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Proces je automatski. Za trenutak vaš pregledač će biti preusmeren na  poželjan sadržaj.';
$pt['Please wait a few seconds:'] = 'Molim da sačekate par sekundi:';
