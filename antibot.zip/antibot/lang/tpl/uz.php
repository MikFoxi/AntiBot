<?php
// This translation has not been verified by a native speaker.
// Uzbek
// Last update: 2020.04.16
$pt['en'] = 'uz';
$pt['Click to continue'] = 'Davom etish uchun bosing';
$pt['Just a moment...'] = 'Kutmoq.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Iltimos JavaScript-ni yoqing va sahifani qayta yuklang.';
$pt['Checking your browser before accessing the website.'] = 'Saytga kirishdan oldin brauzeringizni tekshirish.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Ushbu jarayon avtomatik. Tez orada brauzeringiz talab qilingan tarkibga yo\'naltiradi.';
$pt['Please wait a few seconds:'] = 'Iltimos, bir necha soniya kuting:';
