<?php
// This translation has not been verified by a native speaker.
// Icelandic
// Last update: 2020.04.16
$pt['en'] = 'is';
$pt['Click to continue'] = 'Smelltu til að halda áfram';
$pt['Just a moment...'] = 'Bíddu.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Vinsamlegast kveiktu á JavaScript og endurhladdu síðuna.';
$pt['Checking your browser before accessing the website.'] = 'Athugaðu vafrann þinn áður en þú opnar síðuna.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Þetta ferli er sjálfvirkt. Vafrinn þinn mun vísa á umbeðið efni fljótlega.';
$pt['Please wait a few seconds:'] = 'Bíddu í nokkrar sekúndur:';
