<?php
// This translation has not been verified by a native speaker.
// Slovenian
// Last update: 2021.08.17
$pt['en'] = 'sl';
$pt['Click to continue'] = 'Kliknite za nadaljevanje';
$pt['Just a moment...'] = 'Počakaj.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Vključite JavaScript in znova naložite stran.';
$pt['Checking your browser before accessing the website.'] = 'Preverjanje brskalnika pred dostopom do spletnega mesta.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Ta postopek je samodejen. Vaš brskalnik bo kmalu preusmeril na želeno vsebino.';
$pt['Please wait a few seconds.'] = 'Počakajte nekaj sekund.';
$pt['Loading page, please wait...'] = 'Nalaganje strani, počakajte...';
$pt['BLACK'] = 'ČRNA';
$pt['GRAY'] = 'SIVA';
$pt['PURPLE'] = 'VIJOLIČNA';
$pt['RED'] = 'RDEČA';
$pt['YELLOW'] = 'RUMENA';
$pt['GREEN'] = 'ZELENA';
$pt['BLUE'] = 'MODRA';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Če ste človek, kliknite gumb z barvo, ki je najbolj podobna tej:';
