<?php
// This translation has not been verified by a native speaker.
// Slovenian
// Last update: 2020.05.18
$pt['en'] = 'sl';
$pt['Click to continue'] = 'Kliknite za nadaljevanje';
$pt['Just a moment...'] = 'Počakaj.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Vključite JavaScript in znova naložite stran.';
$pt['Checking your browser before accessing the website.'] = 'Preverjanje brskalnika pred dostopom do spletnega mesta.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Ta postopek je samodejen. Vaš brskalnik bo kmalu preusmeril na želeno vsebino.';
$pt['Please wait a few seconds.'] = 'Počakajte nekaj sekund.';
$pt['Loading page, please wait...'] = 'Nalaganje strani, počakajte...';
