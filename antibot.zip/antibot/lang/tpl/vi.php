<?php
// This translation has not been verified by a native speaker.
// Vietnamese
// Last update: 2021.03.04
$pt['en'] = 'vi';
$pt['Click to continue'] = 'Click để tiếp tục';
$pt['Just a moment...'] = 'Chờ đợi.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Vui lòng bật JavaScript và tải lại trang.';
$pt['Checking your browser before accessing the website.'] = 'Kiểm tra trình duyệt của bạn trước khi truy cập trang web.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Quá trình này là tự động. Trình duyệt của bạn sẽ sớm chuyển hướng đến nội dung bạn yêu cầu.';
$pt['Please wait a few seconds.'] = 'Vui lòng đợi trong vài giây.';
$pt['Loading page, please wait...'] = 'Đang tải trang, vui lòng đợi ...';
$pt['BLACK'] = 'ĐEN';
$pt['GRAY'] = 'XÁM';
$pt['PURPLE'] = 'TÍM';
$pt['RED'] = 'ĐỎ';
$pt['YELLOW'] = 'VÀNG';
$pt['GREEN'] = 'XANH';
$pt['BLUE'] = 'DA TRỜI';
$pt['To verify that you are not a robot, click on the button with color:'] = 'Nếu bạn không phải là rô bốt, hãy nhấp vào nút có màu:';
