<?php
// This translation has not been verified by a native speaker.
// Polski
// Last update: 2020.04.30
$pt['en'] = 'pl';
$pt['Click to continue'] = 'Naciśnij, aby kontynuować';
$pt['Just a moment...'] = 'Trwa sprawdzanie...';
$pt['Please turn JavaScript on and reload the page.'] = 'Prosimy włączyć obsługę JavaScript i zresetować tę stronę.';
$pt['Checking your browser before accessing the website.'] = 'Sprawdzenie przeglądarki internetowej przed dostępem do strony.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Ten proces jest zautomatyzowany. Twoja przeglądarka internetowa zostanie przekierowana do witryny w najbliższym czasie.';
$pt['Please wait a few seconds.'] = 'Prosimy poczekać chwilę.';
