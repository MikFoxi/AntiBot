<?php
// Last update date: 2020.05.06
error_reporting(E_ALL);
ini_set('display_errors', 'on');
header('Content-Type: text/html; charset=UTF-8');
require_once(__DIR__.'/data/conf.php');

echo '<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Test Server</title>
</head>
<body><ul>';
if (exec('whoami') == get_current_user()) {
echo '<li style="color:green;">file owner = php user (good practice)</li>';
} elseif (get_current_user() == 'root') {
echo '<li style="color:red;">Uploading files by the root user is a bad practice!</li>';
} else {
echo '<li style="color:red;">file owner != php user (bad practice)</li>';
}

if (extension_loaded('zip')) {
echo '<li style="color:green;">ZIP - installed</li>';
} else {
echo '<li style="color:red;">ZIP - not installed</li>';
}

//if (class_exists('ZipArchive')) {
//echo '<li style="color:green;">ZipArchive - class installed</li>';
//} else {
//echo '<li style="color:red;">ZipArchive - class not installed</li>';
//}

if (extension_loaded('sqlite3')) {
echo '<li style="color:green;">SQLite3 - installed</li>';
} else {
echo '<li style="color:red;">SQLite3 - not installed</li>';
}

if (extension_loaded('mbstring')) {
echo '<li style="color:green;">Mbstring - installed</li>';
} else {
echo '<li style="color:red;">Mbstring - not installed</li>';
}

if (extension_loaded('memcached')) {
echo '<li style="color:green;">Memcached - installed</li>';
} else {
echo '<li style="color:red;">Memcached - not installed</li>';
}

if (extension_loaded('memcached')) {
$m = new Memcached();
$m->addServer($ab_config['memcached_host'], $ab_config['memcached_port']);
$m->set('memcached_test', 1);
if ($m->get('memcached_test') == 1) {
echo '<li style="color:green;">Memcached - connected</li>';
} else {
echo '<li style="color:red;">Memcached - no connection</li>';
}
}
echo '</ul></body>
</html>';
