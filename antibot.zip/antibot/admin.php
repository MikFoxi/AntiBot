<?php
// Last update date: 2020.04.16
// admin panel
header('X-Powered-CMS: AntiBot.Cloud (See: https://antibot.cloud/)');
header('X-Robots-Tag: noindex');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
define('ANTIBOT', true);
$start_time = microtime(true);

require_once(__DIR__.'/code/include.php');
require_once(__DIR__.'/data/conf.php');
require_once(__DIR__.'/code/func.php');

$host = isset($_SERVER['HTTP_HOST']) ? preg_replace("/[^0-9a-z-.:]/","", $_SERVER['HTTP_HOST']) : '';
$lang_code = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? mb_substr(mb_strtolower(trim(preg_replace("/[^a-zA-Z]/","",$_SERVER['HTTP_ACCEPT_LANGUAGE'])), 'UTF-8'), 0, 2, 'utf-8') : 'en'; // 2 первых символа
$lang_code = isset($_COOKIE['lang_code']) ? mb_substr(mb_strtolower(trim(preg_replace("/[^a-zA-Z]/","",$_COOKIE['lang_code'])), 'UTF-8'), 0, 2, 'utf-8') : $lang_code;

// перевод на язык посетителя:
if (file_exists(__DIR__.'/lang/adm/'.$lang_code.'.php')) {
require_once(__DIR__.'/lang/adm/'.$lang_code.'.php');
}

if ($ab_config['email'] == '' OR $ab_config['pass'] == '') die('EMAIL or PASS not set in /antibot/data/conf.php');

// пост запрос авторизации (установки cookie):
if (isset($_POST['auth_post'])) {
$auth_user = isset($_POST['auth_user']) ? trim($_POST['auth_user']) : ''; // email
$auth_pass = isset($_POST['auth_pass']) ? trim($_POST['auth_pass']) : ''; // pass
$token = md5($auth_user.$ab_config['accept_lang'].$ab_config['useragent'].$ab_config['ip'].$auth_pass.$ab_config['host'].$ab_config['salt']); // токен, основанный на post данных
setcookie('auth_admin_token', $token, $ab_config['time']+86400, '/antibot/');
} else {
$token = isset($_COOKIE['auth_admin_token']) ? trim($_COOKIE['auth_admin_token']) : ''; // token из cookie
}

// проверка авторизации:
if ($token != md5($ab_config['email'].$ab_config['accept_lang'].$ab_config['useragent'].$ab_config['ip'].$ab_config['pass'].$ab_config['host'].$ab_config['salt'])) {
require_once(__DIR__.'/code/loginform.php');
die();
}

if ($ab_config['memcached_counter'] == 1) {
$m = new Memcached();
$m->addServer($ab_config['memcached_host'], $ab_config['memcached_port']);
}

$antibot_db = new SQLite3(__DIR__.'/data/sqlite.db'); 
$antibot_db->busyTimeout(5000);
$antibot_db->exec("PRAGMA journal_mode = WAL;");

// страница админки
$page = isset($_GET['page']) ? preg_replace("/[^0-9a-z]/","",trim($_GET['page'])) : 'index';
if (!file_exists(__DIR__.'/adm/'.$page.'.php')) {$page = 'index';}
require_once(__DIR__.'/adm/'.$page.'.php');

echo '<!DOCTYPE html>
<html lang="'.abTranslate('en').'">
<head>
<title>'.$title.' - '.$host.'</title>
<meta charset="utf-8">
<meta name="robots" content="noindex, nofollow" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="/antibot/static/bootstrap.min.css">
<link rel="stylesheet" href="/antibot/static/offcanvas.css">
<style>.pngflag {height: 16px; border: 1px solid #C0C0C0;}</style>
</head>
<body class="bg-light">
<main role="main" class="container">
<a href="?page=index">
      <div class="d-flex align-items-center p-3 my-3 text-white-50 bg-purple rounded shadow-sm">
        <div class="lh-100">
          <h6 class="mb-0 text-white lh-100">'.$host.'</h6>
          <small>'.abTranslate('Protect Your WebSite').'</small>
        </div>
      </div>
</a>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
<li class="breadcrumb-item"><a href="?page=index" '.(($_GET['page'] == 'index') ? 'class="text-secondary"' : '').'>'.abTranslate('Home').'</a></li>
<li class="breadcrumb-item"><a href="?page=counters" '.(($_GET['page'] == 'counters') ? 'class="text-secondary"' : '').'>'.abTranslate('Statistics').'</a></li>
<li class="breadcrumb-item"><a href="?page=rules" '.(($_GET['page'] == 'rules') ? 'class="text-secondary"' : '').'>'.abTranslate('Rules').'</a></li>
<li class="breadcrumb-item"><a href="?page=hits" '.(($_GET['page'] == 'hits') ? 'class="text-secondary"' : '').'>'.abTranslate('Query Log').'</a></li>
<li class="breadcrumb-item"><a href="?page=fake" '.(($_GET['page'] == 'fake') ? 'class="text-secondary"' : '').'>'.abTranslate('Fake bots').'</a></li>
<li class="breadcrumb-item"><a href="?page=conf" '.(($_GET['page'] == 'conf') ? 'class="text-secondary"' : '').'>conf.php</a></li>
<li class="breadcrumb-item"><a href="?page=counter" '.(($_GET['page'] == 'counter') ? 'class="text-secondary"' : '').'>counter.txt</a></li>
<li class="breadcrumb-item"><a href="?page=tpl" '.(($_GET['page'] == 'tpl') ? 'class="text-secondary"' : '').'>tpl.txt</a></li>
<li class="breadcrumb-item"><a href="?page=error" '.(($_GET['page'] == 'error') ? 'class="text-secondary"' : '').'>error.txt</a></li>
<li class="breadcrumb-item"><a href="?page=update" '.(($_GET['page'] == 'update') ? 'class="text-secondary"' : '').'>'.abTranslate('Update').'</a></li>
<li class="breadcrumb-item"><a href="?page=exit&rand='.$start_time.'">'.abTranslate('Log out').'</a></li>
</ol>
</nav>
<div class="my-3 p-3 bg-white rounded shadow-sm">
';
echo $content;
$exec_time = microtime(true) - $start_time;
$exec_time = round($exec_time, 5);
echo '</div></main>
<br />
<footer class="container border-top text-center text-muted">
        <div class="row">
          <div class="col-12">
<small>
<a href="?page=lang&lang=ru&rand='.$start_time.'" title="на Русском"><img src="flags/RU.png" class="pngflag" /></a> 
<a href="?page=lang&lang=en&rand='.$start_time.'" title="in English"><img src="flags/US.png" class="pngflag" /></a> 
<a href="?page=lang&lang=pl&rand='.$start_time.'" title="po Polsku"><img src="flags/PL.png" class="pngflag" /></a> 
Time: '.$exec_time.' Sec.</small>
</div>
</div>
      </footer>
<br />
</body>
</html>';
