<?php
// Last update date: 2020.04.19
require_once('code/include.php');
echo '<!DOCTYPE html>
<html>
<head>
<title>Antibot Demo Page</title>
<meta charset="utf-8">
</head>
<body>
<center>
<p>You are identified as a '.(($ab_config['whitebot'] == 1) ? 'Good Bot' : 'USER').'. <a href="admin.php">Log in Admin Panel</a>.</p>
<p><a href="https://antibot.cloud/" title="Detect & Block Bad Bot Traffic" target="_blank">Protected by AntiBot.Cloud</a></p>
</center>
</body>
</html>';
