<?php
// This translation has not been verified by a native speaker.
// French
// Last update: 2020.04.30
$pt['en'] = 'fr';
$pt['Click to continue'] = 'Cliquez pour continuer';
$pt['Just a moment...'] = 'Attendez.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Veuillez activer JavaScript et recharger la page.';
$pt['Checking your browser before accessing the website.'] = 'Vérification de votre navigateur avant d\'accéder au site.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Ce processus est automatique. Votre navigateur redirigera vers le contenu demandé sous peu.';
$pt['Please wait a few seconds.'] = 'Veuillez patienter quelques secondes.';
