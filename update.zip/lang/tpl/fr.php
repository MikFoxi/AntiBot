<?php
// This translation has not been verified by a native speaker.
// French
// Last update: 2021.08.17
$pt['en'] = 'fr';
$pt['Click to continue'] = 'Cliquez pour continuer';
$pt['Just a moment...'] = 'Attendez.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Veuillez activer JavaScript et recharger la page.';
$pt['Checking your browser before accessing the website.'] = 'Vérification de votre navigateur avant d\'accéder au site.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Ce processus est automatique. Votre navigateur redirigera vers le contenu demandé sous peu.';
$pt['Please wait a few seconds.'] = 'Veuillez patienter quelques secondes.';
$pt['Loading page, please wait...'] = 'Chargement de la page, veuillez patienter...';
$pt['BLACK'] = 'NOIR';
$pt['GRAY'] = 'GRISE';
$pt['PURPLE'] = 'VIOLET';
$pt['RED'] = 'ROUGE';
$pt['YELLOW'] = 'JAUNE';
$pt['GREEN'] = 'VERT';
$pt['BLUE'] = 'BLEU';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Si vous êtes humain, cliquez sur le bouton dont la couleur ressemble le plus à celle-ci :';
