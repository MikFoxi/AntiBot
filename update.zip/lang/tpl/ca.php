<?php
// This translation has not been verified by a native speaker.
// Catalan, Valencian
// Last update: 2020.04.16
$pt['en'] = 'ca';
$pt['Click to continue'] = 'Feu clic per continuar';
$pt['Just a moment...'] = 'Espera.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Activa JavaScript i torna a carregar la pàgina.';
$pt['Checking your browser before accessing the website.'] = 'Comprovació del navegador abans d’accedir al lloc.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Aquest procés és automàtic. El vostre navegador redirigirà al contingut sol·licitat en breu.';
$pt['Please wait a few seconds:'] = 'Espereu uns segons:';
