<?php
// This translation has not been verified by a native speaker.
// Кыргызча
// Last update: 2020.04.16
$pt['en'] = 'ky';
$pt['Click to continue'] = 'Улантуу үчүн чыкылдатыңыз';
$pt['Just a moment...'] = 'Күт.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Сураныч, JavaScript күйгүзүп, баракчаны кайра жүктөңүз.';
$pt['Checking your browser before accessing the website.'] = 'Сайтка кирерден мурун браузериңизди текшерүү.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Бул процесс автоматтык түрдө жүргүзүлөт. Жакында браузериңиз суралган мазмунга багытталат.';
$pt['Please wait a few seconds:'] = 'Бир нече секунд күтө туруңуз:';
