<?php
// hrvatski
// Last update: 2021.08.17
$pt['en'] = 'hr';
$pt['Click to continue'] = 'Kliknite da nastavite';
$pt['Just a moment...'] = 'Provera je u toku...';
$pt['Please turn JavaScript on and reload the page.'] = 'Molim da omogućite JavaScript u pregledaču i ponovo učitate stranicu.';
$pt['Checking your browser before accessing the website.'] = 'Provera vašeg pregledača pre pristupa stranici.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Proces je automatski. Za trenutak vaš pregledač će biti preusmeren na  poželjan sadržaj.';
$pt['Please wait a few seconds.'] = 'Molim da sačekate par sekundi.';
$pt['Loading page, please wait...'] = 'Učitavanje stranice, pričekajte...';
$pt['BLACK'] = 'CRNO';
$pt['GRAY'] = 'SIVA';
$pt['PURPLE'] = 'LJUBIČASTA';
$pt['RED'] = 'CRVENA';
$pt['YELLOW'] = 'ŽUTA';
$pt['GREEN'] = 'ZELENA';
$pt['BLUE'] = 'PLAVA';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Ako ste čovjek, kliknite gumb s bojom koja je najsličnija ovoj:';
