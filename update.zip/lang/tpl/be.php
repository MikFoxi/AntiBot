<?php
// This translation has not been verified by a native speaker.
// Беларуская мова
// Last update: 2021.08.17
$pt['en'] = 'be';
$pt['Click to continue'] = 'Націсніце, каб працягнуць';
$pt['Just a moment...'] = 'Пачакайце...'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Уключыце JavaScript і перазагрузіце старонку.';
$pt['Checking your browser before accessing the website.'] = 'Праверка браўзэра, перш чым атрымаць доступ да сайта.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Гэты працэс аўтаматычны. Неўзабаве ваш браўзэр перанакіруе на патрэбны вам кантэнт.';
$pt['Please wait a few seconds.'] = 'Пачакайце некалькі секунд.';
$pt['Loading page, please wait...'] = 'Загрузка старонкі, калі ласка, пачакайце...';
$pt['BLACK'] = 'ЧОРНЫ';
$pt['GRAY'] = 'ШЭРЫ';
$pt['PURPLE'] = 'ФІЯЛЕТАВЫ';
$pt['RED'] = 'ЧЫРВОНЫ';
$pt['YELLOW'] = 'ЖОЎТЫ';
$pt['GREEN'] = 'ЗЯЛЁНЫ';
$pt['BLUE'] = 'СІНІ';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Калі вы чалавек, націсніце на кнопку з колерам, найбольш падобным да гэтага:';
