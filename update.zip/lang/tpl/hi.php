<?php
// This translation has not been verified by a native speaker.
// Hindi
// Last update: 2021.08.17
$pt['en'] = 'hi';
$pt['Click to continue'] = 'जारी रखने के लिए चटकाएं';
$pt['Just a moment...'] = 'रुको।'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'कृपया जावास्क्रिप्ट को चालू करें और पृष्ठ को पुनः लोड करें।';
$pt['Checking your browser before accessing the website.'] = 'साइट तक पहुँचने से पहले अपने ब्राउज़र की जाँच करना।';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'यह प्रक्रिया स्वचालित है। आपका ब्राउज़र शीघ्र ही आपकी अनुरोधित सामग्री पर पुनर्निर्देशित कर देगा।';
$pt['Please wait a few seconds.'] = 'कृपया कुछ सेकंड प्रतीक्षा करें.';
$pt['Loading page, please wait...'] = 'पृष्ठ लोड हो रहा है, कृपया प्रतीक्षा करें ...';
$pt['BLACK'] = 'काली';
$pt['GRAY'] = 'धूसर';
$pt['PURPLE'] = 'नील लोहित रंग का';
$pt['RED'] = 'लाल';
$pt['YELLOW'] = 'पीला';
$pt['GREEN'] = 'हरा';
$pt['BLUE'] = 'नीला';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'अगर आप इंसान हैं, तो सबसे समान रंग वाले बटन पर क्लिक करें:';
