<?php
// This translation has not been verified by a native speaker.
// Slovak
// Last update: 2020.05.18
$pt['en'] = 'sk';
$pt['Click to continue'] = 'Pokračujte kliknutím';
$pt['Just a moment...'] = 'Počkať.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Zapnite JavaScript a znova načítajte stránku.';
$pt['Checking your browser before accessing the website.'] = 'Pred prístupom na stránku skontrolujte svoj prehliadač.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Tento proces je automatický. Váš prehliadač čoskoro presmeruje na požadovaný obsah.';
$pt['Please wait a few seconds.'] = 'Počkajte niekoľko sekúnd.';
$pt['Loading page, please wait...'] = 'Načítava sa stránka, čakajte prosím...';
