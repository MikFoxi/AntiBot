<?php
// This translation has not been verified by a native speaker.
// Slovak
// Last update: 2021.08.17
$pt['en'] = 'sk';
$pt['Click to continue'] = 'Pokračujte kliknutím';
$pt['Just a moment...'] = 'Počkať.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Zapnite JavaScript a znova načítajte stránku.';
$pt['Checking your browser before accessing the website.'] = 'Pred prístupom na stránku skontrolujte svoj prehliadač.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Tento proces je automatický. Váš prehliadač čoskoro presmeruje na požadovaný obsah.';
$pt['Please wait a few seconds.'] = 'Počkajte niekoľko sekúnd.';
$pt['Loading page, please wait...'] = 'Načítava sa stránka, čakajte prosím...';
$pt['BLACK'] = 'ČIERNA';
$pt['GRAY'] = 'ŠEDÁ';
$pt['PURPLE'] = 'FIALOVÁ';
$pt['RED'] = 'ČERVENÁ';
$pt['YELLOW'] = 'ŽLTÁ';
$pt['GREEN'] = 'ZELENÁ';
$pt['BLUE'] = 'MODRÁ';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Ak ste človek, kliknite na tlačidlo s farbou, ktorá je najviac podobná tejto:';
