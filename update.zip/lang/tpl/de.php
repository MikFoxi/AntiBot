<?php
// This translation has not been verified by a native speaker.
// German
// Last update: 2021.08.17
$pt['en'] = 'de';
$pt['Click to continue'] = 'Klicke um Fortzufahren';
$pt['Just a moment...'] = 'Warten.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Bitte schalten Sie JavaScript ein und laden Sie die Seite neu.';
$pt['Checking your browser before accessing the website.'] = 'Überprüfen Sie Ihren Browser, bevor Sie auf die Website zugreifen.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Dieser Vorgang erfolgt automatisch. Ihr Browser wird in Kürze zu Ihrem gewünschten Inhalt umleiten.';
$pt['Please wait a few seconds.'] = 'Bitte warten Sie einige Sekunden.';
$pt['Loading page, please wait...'] = 'Seite laden, bitte warten...';
$pt['BLACK'] = 'SCHWARZ';
$pt['GRAY'] = 'GRAU';
$pt['PURPLE'] = 'LILA';
$pt['RED'] = 'ROT';
$pt['YELLOW'] = 'GELB';
$pt['GREEN'] = 'GRÜN';
$pt['BLUE'] = 'BLAU';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Wenn Sie ein Mensch sind, klicken Sie auf die Schaltfläche mit der Farbe, die dieser am ähnlichsten ist:';
