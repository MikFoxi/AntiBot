<?php
// This translation has not been verified by a native speaker.
// Lithuanian
// Last update: 2021.03.03
$pt['en'] = 'lt';
$pt['Click to continue'] = 'Spustelėkite, jei norite tęsti';
$pt['Just a moment...'] = 'Laukti.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Įjunkite „JavaScript“ ir iš naujo įkelkite puslapį.';
$pt['Checking your browser before accessing the website.'] = 'Prieš eidami į svetainę, patikrinkite savo naršyklę.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Šis procesas vyksta automatiškai. Netrukus jūsų naršyklė nukreips į jūsų reikalaujamą turinį.';
$pt['Please wait a few seconds.'] = 'Palaukite kelias sekundes.';
$pt['Loading page, please wait...'] = 'Įkeliamas puslapis, palaukite...';
$pt['BLACK'] = 'JUODA';
$pt['GRAY'] = 'PILKA';
$pt['PURPLE'] = 'VIOLETINĖ';
$pt['RED'] = 'RAUDONA';
$pt['YELLOW'] = 'GELTONA';
$pt['GREEN'] = 'ŽALIAS';
$pt['BLUE'] = 'MĖLYNA';
$pt['To verify that you are not a robot, click on the button with color:'] = 'Jei nesate robotas, spustelėkite mygtuką su spalva:';
