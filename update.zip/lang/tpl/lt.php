<?php
// This translation has not been verified by a native speaker.
// Lithuanian
// Last update: 2020.04.16
$pt['en'] = 'lt';
$pt['Click to continue'] = 'Spustelėkite, jei norite tęsti';
$pt['Just a moment...'] = 'Laukti.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Įjunkite „JavaScript“ ir iš naujo įkelkite puslapį.';
$pt['Checking your browser before accessing the website.'] = 'Prieš eidami į svetainę, patikrinkite savo naršyklę.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Šis procesas vyksta automatiškai. Netrukus jūsų naršyklė nukreips į jūsų reikalaujamą turinį.';
$pt['Please wait a few seconds:'] = 'Palaukite kelias sekundes:';
