<?php
// This translation has not been verified by a native speaker.
// Czech
// Last update: 2021.03.03
$pt['en'] = 'cs';
$pt['Click to continue'] = 'Klikni pro pokračování';
$pt['Just a moment...'] = 'Počkejte.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Zapněte prosím JavaScript a znovu načtěte stránku.';
$pt['Checking your browser before accessing the website.'] = 'Před přístupem na web zkontrolujte svůj prohlížeč.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Tento proces je automatický. Váš prohlížeč brzy přesměruje na požadovaný obsah.';
$pt['Please wait a few seconds.'] = 'Počkejte prosím několik sekund.';
$pt['Loading page, please wait...'] = 'Načítám stránku, prosím čekejte...';
$pt['BLACK'] = 'ČERNÁ';
$pt['GRAY'] = 'ŠEDÁ';
$pt['PURPLE'] = 'NACHOVÝ';
$pt['RED'] = 'ČERVENÉ';
$pt['YELLOW'] = 'ŽLUTÁ';
$pt['GREEN'] = 'ZELENÝ';
$pt['BLUE'] = 'MODRÝ';
$pt['To verify that you are not a robot, click on the button with color:'] = 'Pokud nejste robot, klikněte na tlačítko s barvou:';
