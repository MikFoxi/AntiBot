<?php
// This translation has not been verified by a native speaker.
// Burmese
// Last update: 2020.05.18
$pt['en'] = 'my';
$pt['Click to continue'] = 'ဆက်ရန်ကိုနှိပ်ပါ';
$pt['Just a moment...'] = 'စောင့်ပါ'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'ကျေးဇူးပြု၍ JavaScript ကိုဖွင့ ်၍ စာမျက်နှာကိုပြန်ဖွင့်ပါ။';
$pt['Checking your browser before accessing the website.'] = 'ဆိုက်ကိုမဝင်ရောက်မီသင့် browser ကိုစစ်ဆေးခြင်း။';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'ဤလုပ်ငန်းစဉ်သည်အလိုအလျောက်ဖြစ်သည်။ သင်၏ browser သည်သင်တောင်းဆိုထားသောအကြောင်းအရာသို့မကြာမီရောက်လိမ့်မည်။';
$pt['Please wait a few seconds.'] = 'ကျေးဇူးပြု၍ စက္ကန့်အနည်းငယ်စောင့်ပါ';
$pt['Loading page, please wait...'] = 'စာမျက်နှာတင်နေသည် ကျေးဇူးပြု၍ ခဏစောင့်ပါ';
