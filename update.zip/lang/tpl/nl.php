<?php
// This translation has not been verified by a native speaker.
// Nederlands
// Last update: 2020.04.16
$pt['en'] = 'nl';
$pt['Click to continue'] = 'Klik om verder te gaan';
$pt['Just a moment...'] = 'Wacht.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Schakel JavaScript in en laad de pagina opnieuw.';
$pt['Checking your browser before accessing the website.'] = 'Controleer uw browser voordat u de site bezoekt.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Dit proces verloopt automatisch. Uw browser zal binnenkort doorverwijzen naar de door u gevraagde inhoud.';
$pt['Please wait a few seconds:'] = 'Wacht een paar seconden:';
