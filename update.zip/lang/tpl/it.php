<?php
// This translation has not been verified by a native speaker.
// Italian
// Last update: 2021.03.03
$pt['en'] = 'it';
$pt['Click to continue'] = 'Clicca per continuare';
$pt['Just a moment...'] = 'Aspettare.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Attiva JavaScript e ricarica la pagina.';
$pt['Checking your browser before accessing the website.'] = 'Verifica il tuo browser prima di accedere al sito.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Questo processo è automatico. A breve il tuo browser reindirizzerà al contenuto richiesto.';
$pt['Please wait a few seconds.'] = 'Attendi qualche secondo.';
$pt['Loading page, please wait...'] = 'Caricamento pagina in corso, attendere...';
$pt['BLACK'] = 'NERO';
$pt['GRAY'] = 'GRIGIO';
$pt['PURPLE'] = 'VIOLA';
$pt['RED'] = 'ROSSO';
$pt['YELLOW'] = 'GIALLO';
$pt['GREEN'] = 'VERDE';
$pt['BLUE'] = 'BLU';
$pt['To verify that you are not a robot, click on the button with color:'] = 'Se non sei un robot, fai clic sul pulsante con il colore:';
