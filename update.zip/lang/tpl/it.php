<?php
// This translation has not been verified by a native speaker.
// Italian
// Last update: 2020.04.16
$pt['en'] = 'it';
$pt['Click to continue'] = 'Clicca per continuare';
$pt['Just a moment...'] = 'Aspettare.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Attiva JavaScript e ricarica la pagina.';
$pt['Checking your browser before accessing the website.'] = 'Verifica il tuo browser prima di accedere al sito.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Questo processo è automatico. A breve il tuo browser reindirizzerà al contenuto richiesto.';
$pt['Please wait a few seconds:'] = 'Attendi qualche secondo:';
