<?php
// This translation has not been verified by a native speaker.
// Swedish
// Last update: 2020.04.16
$pt['en'] = 'sv';
$pt['Click to continue'] = 'Klicka för att fortsätta';
$pt['Just a moment...'] = 'Vänta.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Vänligen aktivera JavaScript och ladda om sidan igen.';
$pt['Checking your browser before accessing the website.'] = 'Kontrollera din webbläsare innan du går in på webbplatsen.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Denna process är automatisk. Din webbläsare kommer att omdirigera till det begärda innehållet inom kort.';
$pt['Please wait a few seconds:'] = 'Vänta några sekunder:';
