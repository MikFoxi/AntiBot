<?php
// This translation has not been verified by a native speaker.
// Hungarian
// Last update: 2021.08.17
$pt['en'] = 'hu';
$pt['Click to continue'] = 'Kattintson a folytatáshoz';
$pt['Just a moment...'] = 'Várjon.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Kérjük, kapcsolja be a JavaScriptet, és töltse újra az oldalt.';
$pt['Checking your browser before accessing the website.'] = 'Ellenőrizze a böngészőt, mielőtt belépne a webhelyre.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Ez a folyamat automatikus. Böngészője hamarosan átirányítja a kért tartalomra.';
$pt['Please wait a few seconds.'] = 'Kérjük, várjon néhány másodpercet.';
$pt['Loading page, please wait...'] = 'Az oldal betöltése folyamatban, kérem várjon...';
$pt['BLACK'] = 'FEKETE';
$pt['GRAY'] = 'SZÜRKE';
$pt['PURPLE'] = 'LILA';
$pt['RED'] = 'PIROS';
$pt['YELLOW'] = 'SÁRGA';
$pt['GREEN'] = 'ZÖLD';
$pt['BLUE'] = 'KÉK';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Ha ember vagy, kattints a gombra, amelynek színe a leginkább hasonlít ehhez:';
