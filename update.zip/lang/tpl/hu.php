<?php
// This translation has not been verified by a native speaker.
// Hungarian
// Last update: 2020.04.30
$pt['en'] = 'hu';
$pt['Click to continue'] = 'Kattintson a folytatáshoz';
$pt['Just a moment...'] = 'Várjon.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Kérjük, kapcsolja be a JavaScriptet, és töltse újra az oldalt.';
$pt['Checking your browser before accessing the website.'] = 'Ellenőrizze a böngészőt, mielőtt belépne a webhelyre.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Ez a folyamat automatikus. Böngészője hamarosan átirányítja a kért tartalomra.';
$pt['Please wait a few seconds.'] = 'Kérjük, várjon néhány másodpercet.';
