<?php
// This translation has not been verified by a native speaker.
// Română
// Last update: 2021.03.04
$pt['en'] = 'ro';
$pt['Click to continue'] = 'Apasă pentru a continua';
$pt['Just a moment...'] = 'Aștepta.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Vă rugăm să activați JavaScript și să reîncărcați pagina.';
$pt['Checking your browser before accessing the website.'] = 'Verificați browserul dvs. înainte de a accesa site-ul.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Acest proces este automat. Browserul dvs. va redirecționa în scurt timp către conținutul solicitat.';
$pt['Please wait a few seconds.'] = 'Vă rugăm să așteptați câteva secunde.';
$pt['Loading page, please wait...'] = 'Se încarcă pagina, vă rugăm să așteptați...';
$pt['BLACK'] = 'NEGRU';
$pt['GRAY'] = 'GRI';
$pt['PURPLE'] = 'VIOLET';
$pt['RED'] = 'ROȘU';
$pt['YELLOW'] = 'GALBEN';
$pt['GREEN'] = 'VERDE';
$pt['BLUE'] = 'ALBASTRU';
$pt['To verify that you are not a robot, click on the button with color:'] = 'Dacă nu sunteți un robot, faceți clic pe butonul cu culoarea:';
