<?php
// This translation has not been verified by a native speaker.
// Polski
// Last update: 2021.08.17
$pt['en'] = 'pl';
$pt['Click to continue'] = 'Naciśnij, aby kontynuować';
$pt['Just a moment...'] = 'Trwa sprawdzanie...';
$pt['Please turn JavaScript on and reload the page.'] = 'Prosimy włączyć obsługę JavaScript i zresetować tę stronę.';
$pt['Checking your browser before accessing the website.'] = 'Sprawdzenie przeglądarki internetowej przed dostępem do strony.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Ten proces jest zautomatyzowany. Twoja przeglądarka internetowa zostanie przekierowana do witryny w najbliższym czasie.';
$pt['Please wait a few seconds.'] = 'Prosimy poczekać chwilę.';
$pt['Loading page, please wait...'] = 'Ładowanie strony, proszę czekać...';
$pt['BLACK'] = 'CZARNY';
$pt['GRAY'] = 'SZARY';
$pt['PURPLE'] = 'FIOLETOWY';
$pt['RED'] = 'CZERWONY';
$pt['YELLOW'] = 'ŻÓŁTY';
$pt['GREEN'] = 'ZIELONY';
$pt['BLUE'] = 'NIEBIESKI';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Jeśli jesteś człowiekiem, kliknij przycisk w kolorze najbardziej zbliżonym do tego:';
