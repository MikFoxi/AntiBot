<?php
// This translation has not been verified by a native speaker.
// Chinese
// Last update: 2021.03.04
$pt['en'] = 'zh';
$pt['Click to continue'] = '点击继续';
$pt['Just a moment...'] = '等待。'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = '请打开JavaScript并重新加载页面。';
$pt['Checking your browser before accessing the website.'] = '访问网站之前，请检查浏览器。';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = '此过程是自动的。 您的浏览器将很快重定向到您请求的内容。';
$pt['Please wait a few seconds.'] = '请等待几秒钟';
$pt['Loading page, please wait...'] = '正在加载页面，请稍候...';
$pt['BLACK'] = '黑色的';
$pt['GRAY'] = '灰色的';
$pt['PURPLE'] = '紫色的';
$pt['RED'] = '红色的';
$pt['YELLOW'] = '黄色的';
$pt['GREEN'] = '绿色';
$pt['BLUE'] = '蓝色';
$pt['To verify that you are not a robot, click on the button with color:'] = '如果您不是机器人，请单击以下颜色的按钮：';
