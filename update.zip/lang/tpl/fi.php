<?php
// This translation has not been verified by a native speaker.
// Finnish (suomi)
// Last update: 2021.08.17
$pt['en'] = 'fi';
$pt['Click to continue'] = 'Klikkaa jatkaaksesi';
$pt['Just a moment...'] = 'Odota.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Ota JavaScript käyttöön ja lataa sivu uudelleen.';
$pt['Checking your browser before accessing the website.'] = 'Selaimen tarkistaminen ennen pääsyä sivustoon.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Tämä prosessi on automaattinen. Selaimesi ohjaa pian pyydettyyn sisältöön.';
$pt['Please wait a few seconds.'] = 'Odota muutama sekunti.';
$pt['Loading page, please wait...'] = 'Ladataan sivua, odota ...';
$pt['BLACK'] = 'MUSTA';
$pt['GRAY'] = 'HARMAA';
$pt['PURPLE'] = 'VIOLETTI';
$pt['RED'] = 'PUNAINEN';
$pt['YELLOW'] = 'KELTAINEN';
$pt['GREEN'] = 'VIHREÄ';
$pt['BLUE'] = 'SININEN';
$pt['If you are human, click on the button with the color most similar to this one:'] = 'Jos olet ihminen, napsauta painiketta, jonka väri on eniten samanlainen kuin tämä:';
