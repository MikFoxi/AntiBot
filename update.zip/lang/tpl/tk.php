<?php
// This translation has not been verified by a native speaker.
// Turkmen
// Last update: 2020.05.18
$pt['en'] = 'tk';
$pt['Click to continue'] = 'Dowam etmek üçin basyň';
$pt['Just a moment...'] = 'Garaş.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'JavaScript-i açyň we sahypany täzeden açyň.';
$pt['Checking your browser before accessing the website.'] = 'Sahypa girmezden ozal brauzeriňizi barlamak.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Bu amal awtomatiki. Brauzeriňiz gysga wagtda talap edilýän mazmuna gönükdiriler.';
$pt['Please wait a few seconds.'] = 'Birnäçe sekunt garaşyň.';
$pt['Loading page, please wait...'] = 'Sahypa ýüklenýär, garaşyň...';
