<?php
// Last update date: 2020.04.06
if(!defined('ANTIBOT')) die('access denied');

$title = abTranslate('Edit counter.txt');
$content = '';
if (isset($_POST['submit'])) {
$_POST['counter'] = isset($_POST['counter']) ? trim($_POST['counter']) : '';
file_put_contents(__DIR__.'/../data/counter.txt', $_POST['counter'], LOCK_EX);
$content .= '<div class="alert alert-success" role="alert">
  '.abTranslate('Settings have been saved.').'
</div>';
}
$content .= '<p>'.abTranslate('File /antibot/data/counter.txt - is designed to insert html or js code of statistics counters (Google Analytics, Yandex.Metrica, etc.).').'</p>
<form action="" method="post">
  <div class="form-group">
<textarea name="counter" rows="13" class="form-control">
'.file_get_contents(__DIR__.'/../data/counter.txt').'
</textarea>  
</div>
 <div class="form-group"> 
  <button name="submit" type="submit" class="btn btn-info btn-sm">'.abTranslate('Save Settings').'</button>
  </div>
</form>';
