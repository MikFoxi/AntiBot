<?php
// Last update date: 2022.04.06
if(!defined('ANTIBOT')) die('access denied');

$title = abTranslate('Home');

$size = filesize(__DIR__.'/../data/sqlite.db');

$content .= '
<div id="new_version_msg" class="alert alert-success" role="alert" style="display:none">'.abTranslate('A new version of the antibot is now available. In order to upgrade, visit page:').' <a href="?'.$abw.$abp.'=update">'.abTranslate('Update').'</a></div>';
if(function_exists('sys_getloadavg')) {
$content .= '<p>Loade average: '.@implode(' ', sys_getloadavg()).'</p>';
}
$content .= '<p>'.abTranslate('Database file size').' data/sqlite.db: '.round($size / 1024 / 1024, 2).' Mb.</p>';
if ($ab_config['memcached_counter'] == 1) {
$getStats = $ab_memcached->getStats();
if (is_array($getStats)) {
foreach($getStats as $getStat) {
//print_r($getStat);
$content .= '<p>Memcached '.abTranslate('used').' '.round($getStat['bytes'] / 1024 / 1024, 2).' '.abTranslate('of').' '.round($getStat['limit_maxbytes'] / 1024 / 1024, 2).' Mb ('.round($getStat['bytes'] * 100 / $getStat['limit_maxbytes'], 2).'%).</p>
<p>Memcached Uptime: '.$getStat['uptime'].' sec.</p>';
}
}
}

// новости:
$content .= '<span id="other_ab_msg"></span>';

$content .= '<script>var current_version = '.$ab_version.';</script>
<script src="https://antibot.cloud/version.php?data='.md5('Antibot:'.$ab_config['email']).'|'.md5($ab_config['check_url']).'|'.$ab_version.'|'.$ab_config['cms'].'" async></script>

<script>
var xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
if (this.readyState == 2 && this.status == 200) {
document.getElementById("warning").innerHTML = "<div class=\"alert alert-danger\"><a href=\"data/sqlite.db\" target=\"_blank\">data/sqlite.db</a> - '.abTranslate('The database file has a server response code of 200. It may be available for download. This is unsafe because the database may contain confidential data. Protect the database file from web access.').'</div>";
}
};
xmlhttp.timeout = 1000;
xmlhttp.open("GET", "data/sqlite.db", true);
xmlhttp.send();
</script>
';
