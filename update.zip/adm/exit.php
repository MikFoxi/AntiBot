<?php
// Last update date: 2020.04.02
if(!defined('ANTIBOT')) die('access denied');

$title = abTranslate('Log out');

setcookie('auth_admin_token', 'null', $ab_config['time']-100, '/antibot/');

header('HTTP/1.1 301 Moved Permanently');
header('Location: ?page=index');
