<?php
// Last update date: 2020.04.21
if(!defined('ANTIBOT')) die('access denied');

$title = abTranslate('Edit tpl.txt');
$content = '';
if (isset($_POST['submit'])) {
$_POST['tpl'] = isset($_POST['tpl']) ? trim($_POST['tpl']) : '';
if ($_POST['tpl'] != '') {
file_put_contents(__DIR__.'/../data/tpl.txt', $_POST['tpl'], LOCK_EX);
$content .= '<div class="alert alert-success" role="alert">
  '.abTranslate('Settings have been saved.').'
</div>';
}
}
$content .= '<p>'.abTranslate('File /antibot/data/tpl.txt - template of the AntiBot check page. Make a backup of the template before edit.').'</p>
<form action="" method="post">
  <div class="form-group">
<textarea name="tpl" rows="13" class="form-control">
'.file_get_contents(__DIR__.'/../data/tpl.txt').'
</textarea>  
</div>
 <div class="form-group"> 
  <button name="submit" type="submit" class="btn btn-info btn-sm">'.abTranslate('Save Settings').'</button>
  </div>
</form>';
