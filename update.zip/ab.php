<?php
// Last update: 2020.04.16
// скрипт локальной проверки посетителя.

header('X-Powered-CMS: AntiBot.Cloud (See: https://antibot.cloud/)');
header('X-Robots-Tag: noindex');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');

require_once(__DIR__.'/data/conf.php');
require_once(__DIR__.'/code/func.php');

// if ($_SERVER['SERVER_PROTOCOL'] != 'HTTP/2.0') die(); // если ваш сервер поддерживает http2
$time = time();
$ab_config['cid'] = isset($_GET['cid']) ? trim(preg_replace("/[^0-9\.]/","", $_GET['cid'])) : die('cid'); // уник id клика
$ab_config['referer'] = isset($_SERVER['HTTP_REFERER']) ? trim(strip_tags($_SERVER['HTTP_REFERER'])) : '';
$ab_config['host'] = isset($_SERVER['HTTP_HOST']) ? preg_replace("/[^0-9a-z-.:]/","", $_SERVER['HTTP_HOST']) : '';
$ab_config['useragent'] = isset($_SERVER['HTTP_USER_AGENT']) ? trim(strip_tags($_SERVER['HTTP_USER_AGENT'])) : '';
$ab_config['accept_lang'] = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? trim(strip_tags($_SERVER['HTTP_ACCEPT_LANGUAGE'])) : '';
if ($ab_config['timer'] < 1) {$ab_config['timer'] = 1;}

// cid - уник клик должен быть уник, второй раз тут делать нечего:
if (isset($_COOKIE['ab_stop_'.$ab_config['cid']])) {
echo '<center style="color:red;">Error Code: double click</center>';
die();
}
setcookie('ab_stop_'.$ab_config['cid'], 1, $time+86400, '/');

if ($ab_config['referer'] == '') {
echo '<center style="color:red;">Error Code: 1</center>';
die();
}

if ($ab_config['useragent'] == '') {
echo '<center style="color:red;">Error Code: 2</center>';
die();
}

if ($ab_config['check_url'] == '') die();

// укороченный ип:
$ip_short = isset($_GET['ip']) ? trim(preg_replace("/[^0-9a-zA-Z\.\:]/","", $_GET['ip'])) : '';
// полный хэш:
$h1 = isset($_GET['h1']) ? trim(preg_replace("/[^0-9a-z]/","", $_GET['h1'])) : '';

// таким должен быть правильный хэш:
$antibot = md5($ab_config['email'].$ab_config['pass'].$ab_config['host'].$ab_config['useragent'].$ab_config['accept_lang'].$ip_short.$ab_config['cf_check'].$ab_config['re_check'].$ab_config['ho_check']);

if ($antibot != $h1) {
echo '<center style="color:red;">Error Code: 3</center>';
die();
}

$hash = md5($ab_config['pass'].$ab_config['host'].$ab_config['useragent'].$ip_short); // код для куки
$ab_cookiename = 'antibot_'.md5($ab_config['salt'].$ab_config['host'].$ip_short);

echo '<script>
if(self == top) {
window.location.href = "/";
throw "stop";
}
var d = new Date();
d.setTime(d.getTime() + (1*24*60*60*1000));
var expires = "expires="+ d.toUTCString();
document.cookie = "'.$ab_cookiename.'='.$hash.'; " + expires + "; path=/;";
setTimeout("window.top.location.reload();", '.$ab_config['timer'].'000 );
</script>
';

// обновление лога о проходе заглушки:
if ($ab_config['antibot_log_tests'] == 1) {
// коннект к базе:
$antibot_db = new SQLite3(__DIR__.'/data/sqlite.db'); 
$antibot_db->busyTimeout(5000);
$antibot_db->exec("PRAGMA journal_mode = WAL;");
$update = $antibot_db->exec("UPDATE hits SET passed='1' WHERE cid='".$ab_config['cid']."';");
}

// подключаемся к мемкешеду:
if ($ab_config['memcached_counter'] == 1) {
$ab_memcached = new Memcached();
$ab_memcached->addServer($ab_config['memcached_host'], $ab_config['memcached_port']);
// счетчик автоматически прошедших:
$ab_mem = $ab_memcached->increment($ab_config['memcached_prefix'].'auto_'.date('Ymd', $time), 1);
if (!$ab_mem) {$ab_memcached->set($ab_config['memcached_prefix'].'auto_'.date('Ymd', $time), 1);}
}
